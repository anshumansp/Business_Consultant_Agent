import React from 'react'

const Phone = () => {
  return (
    <div style={{
        width: "100%",
        height: "60vh",
        textAlign: "center",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        fontSize: "24px"
    }}>
      To be added soon
    </div>
  )
}

export default Phone
